﻿namespace ClientSiteMVC.Models
{
    public class JwtTokenResponse
    {
        public string Token { get; set; }
    }
}

﻿using ClientSiteMVC.Models;
using ClientSiteMVC.Services;
using Microsoft.AspNetCore.Mvc;

namespace ClientSiteMVC.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IProductServices _productService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ProductsController(IProductServices productService, IHttpContextAccessor httpContextAccessor)
        {
            _productService = productService;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        public async Task<IActionResult> Dashboard()
        {
            var token = _httpContextAccessor.HttpContext.Session.GetString("JWToken");

            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Account");
            }

            var products = await _productService.GetProductsAsync(token);
            return View(products);
        }

        [HttpGet]
        public IActionResult AddProduct() => View();

        [HttpPost]
        public async Task<IActionResult> AddProduct(Product product, IFormFile imageFile)
        {
            var token = _httpContextAccessor.HttpContext.Session.GetString("JWToken");

            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Account");
            }

            if (ModelState.IsValid)
            {
                var result = await _productService.AddProductAsync(product, imageFile, token);

                if (string.IsNullOrEmpty("result"))
                {
                    return RedirectToAction("Dashboard");
                }

                ModelState.AddModelError("", "Error adding product.");
            }

            return View(product);
        }

        // Edit Product
        [HttpGet]
        public async Task<IActionResult> EditProduct(int id)
        {
            var token = _httpContextAccessor.HttpContext.Session.GetString("JWToken");

            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Account");
            }

            var product = await _productService.GetProductByIdAsync(id, token);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> EditProduct(Product product, IFormFile imageFile)
        {
            var token = _httpContextAccessor.HttpContext.Session.GetString("JWToken");

            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Account");
            }

            if (ModelState.IsValid)
            {
                var result = await _productService.UpdateProductAsync(product, imageFile, token);

                if (string.IsNullOrEmpty(result))
                {
                    return RedirectToAction("Dashboard");
                }

                ModelState.AddModelError("", "Error updating product.");
            }

            return View(product);
        }

        // Delete Product
        [HttpPost]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var token = _httpContextAccessor.HttpContext.Session.GetString("JWToken");

            if (string.IsNullOrEmpty(token))
            {
                return RedirectToAction("Login", "Account");
            }

            var result = await _productService.DeleteProductAsync(id, token);

            if (string.IsNullOrEmpty(result))
            {
                return RedirectToAction("Dashboard");
            }

            ModelState.AddModelError("", "Error deleting product.");
            return RedirectToAction("Dashboard");
        }
    }
}

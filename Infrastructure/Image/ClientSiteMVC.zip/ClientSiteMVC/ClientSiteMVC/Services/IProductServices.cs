﻿using ClientSiteMVC.Models;

namespace ClientSiteMVC.Services
{
    public interface IProductServices
    {
        //Task<IEnumerable<Product>> GetProductsAsync(string token);
        //Task<bool> AddProductAsync(Product product, IFormFile imageFile, string token);
        //Task UpdateProductAsync(Product product, IFormFile productImage, string token);
        //Task DeleteProductAsync(int id, string token);
        Task<IEnumerable<Product>> GetProductsAsync(string token);
        Task<Product> GetProductByIdAsync(int id, string token); // Ensure this method is present
        Task<string> AddProductAsync(Product product, IFormFile imageFile, string token); // Return type should be string
        Task<string> UpdateProductAsync(Product product, IFormFile imageFile, string token); // Ensure this method is present
        Task<string> DeleteProductAsync(int id, string token);
    }
}

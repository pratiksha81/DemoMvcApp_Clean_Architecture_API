﻿using ClientSiteMVC.Models;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace ClientSiteMVC.Services
{
    public class ProductServices : IProductServices
    {
        private readonly HttpClient _httpClient;

        public ProductServices(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IEnumerable<Product>> GetProductsAsync(string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await _httpClient.GetAsync("https://localhost:7055/api/Products");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<IEnumerable<Product>>();
        }

        public async Task<Product> GetProductByIdAsync(int id, string token) // Corrected method implementation
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await _httpClient.GetAsync($"https://localhost:7055/api/Products/{id}");
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadFromJsonAsync<Product>();
        }

        public async Task<string> AddProductAsync(Product product, IFormFile imageFile, string token) // Correct return type
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var formData = new MultipartFormDataContent();
            formData.Add(new StringContent(product.Name), "Name");
            formData.Add(new StringContent(product.Price.ToString()), "Price");

            if (imageFile != null)
            {
                using (var stream = new MemoryStream())
                {
                    await imageFile.CopyToAsync(stream);
                    var imageContent = new ByteArrayContent(stream.ToArray());
                    imageContent.Headers.ContentType = new MediaTypeHeaderValue(imageFile.ContentType);
                    formData.Add(imageContent, "ImageFile", imageFile.FileName);
                }
            }

            var response = await _httpClient.PostAsync("https://localhost:7055/api/Products", formData);
            return response.IsSuccessStatusCode ? string.Empty : "Error adding product."; // Return appropriate message
        }

        public async Task<string> UpdateProductAsync(Product product, IFormFile imageFile, string token) // Add Update method
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var formData = new MultipartFormDataContent();
            formData.Add(new StringContent(product.Id.ToString()), "Id");
            formData.Add(new StringContent(product.Name), "Name");
            formData.Add(new StringContent(product.Price.ToString()), "Price");

            if (imageFile != null)
            {
                using (var stream = new MemoryStream())
                {
                    await imageFile.CopyToAsync(stream);
                    var imageContent = new ByteArrayContent(stream.ToArray());
                    imageContent.Headers.ContentType = new MediaTypeHeaderValue(imageFile.ContentType);
                    formData.Add(imageContent, "ImageFile", imageFile.FileName);
                }
            }

            var response = await _httpClient.PutAsync($"https://localhost:7055/api/Products/{product.Id}", formData);
            return response.IsSuccessStatusCode ? string.Empty : "Error updating product."; // Return appropriate message
        }

        public async Task<string> DeleteProductAsync(int id, string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var response = await _httpClient.DeleteAsync($"https://localhost:7055/api/Products/{id}");

            return response.IsSuccessStatusCode ? string.Empty : "Error deleting product."; // Return appropriate message
        }
    }
}
